# Gridly for UE5.6

Gridly is the #1 spreadsheet for multi-language content. Bring your digital assets together and localize at speed!

Manage your game’s data as a single source of truth and roll out continuous updates with full localization support & version control.

## Prerequisites

- Unreal Engine 5.6

## Getting Started

Before you use Gridly, you will need to sign up for an account at https://www.gridly.com

Download the Gridly plugin itself, as well as the sample project to get you started:

- [Gridly UE 5.6 Plugin](https://github.com/gridly-spreadsheet-CMS/gridly-ue-5.6-plugin)

The sample project is optional, but provides a working example project for reference that has a very basic user interface set up for localization in UE5.6.

### Setting up a Project for Localization

Gridly plugin for UE5.6 leverages Unreal's built-in tools for localization. If you are not familiar with Unreal's localization pipeline, please consult [their documentation](https://docs.unrealengine.com/en-US/ProductionPipelines/Localization/Overview/index.html).

This guide assumes that you are already familiar with Unreal's tools, and that you've correctly set up all the text in your project for localization using this workflow. The plugin supports both inline source strings and the use of StringTables.

### Installing the Plugin

The plugin can be installed as either an engine plugin or a project plugin.

#### As a Project Plugin

- Extract the contents of Gridly UE5.6 Plugin repository to `Plugins/Gridly` (relative to project root).
- Generate project files for the project and build the project to compile the required DLLs for the project plugin.

#### As an Engine Plugin

- Extract the contents of Gridly UE5.6 Plugin repository to `Engine/Plugins/Gridly` (relative to engine root).
- Generate project files for the engine and build again to compile the required DLLs for the plugin.

### Enabling the Plugin

To enable the plugin in your project, go to `Edit -> Plugins` and search for `Gridly`.

![Enable Gridly UE5.6 Plugin](Documentation/EnablePlugin.png)

Once enabled, restart Unreal to load the plugin.

### Changing the Localization Service Provider

In the Localization Dashboard, you should now be able to choose Gridly as your Localization Service Provider. Once selected, close the Localization Dashboard and re-open it to load the toolbar buttons.

![Choose Localizaton Service Provider](Documentation/ChooseLocalizationServiceProvider.png)

If you do not have access to the Localization Dashboard, you need to enable it. Go to `Edit -> Editor Preferences` and search for `Localization Dashboard` to activate it.

![Enable Localization Dashboard](Documentation/EnableLocalizationDashboard.png)

Once enabled, restart Unreal to be able to find the Localization Dashboard option under `Window -> Localization Dashboard`.

## Synchronizing with Gridly

Before you can export your source strings to Gridly, you need to first set up a new Grid in Gridly. Here is an example using FIGS:

![Create the Grid](Documentation/CreateGrid.png)

You will also need to set up your project to target the same cultures in the Localization Dashboard.

![Setting up Cultures](Documentation/Cultures.png)

*Important!* Make sure these locale/culture codes match the ones on Gridly (hover over them to show tooltip). For the sample project, make sure you rename the columns on Gridly `src_enUS`, `tg_frFR`, `tg_itIT`, `tg_deDE` and `tg_esES`. To do this in Gridly, choose "Column Properties" on the column header. If you have previously set this up with codes that do not match those in Gridly, or you wish to map them in a different way, see how you can [customize the mapping](#markdown-header-custom-culture-mapping).

### Setting up the API keys and view IDs

To communicate with the API, you need to make sure that you have configured the plugin to use the correct API keys. You also need to set which view IDs you wish to use for import/export. See [import/export settings](#markdown-header-importexport-settings) for more information.

### Exporting Native Source Strings

Once you have made sure that your source and target languages are set up correctly and matching in both Unreal and on Gridly, and you have gathered all your source text, you can now export all source strings by pressing the `Export to Gridly`-button on the Localization Dashboard.

![Export to Gridly](Documentation/ExportGridly.png)

After export, open the Grid in your browser to edit the translations in the browser (may require refresh to see changes).

You can use the Sync records setting in the plugin settings to delete the records from Gridly that has been removed from UE. This setting may slow down the export process, because after it send to entries into Gridly, it checks whether the Grid has any record that not exists in the game target you sent.

### Importing Translations

After you're done translating, you can import translations for all target cultures back to project with just a single click.

![Import from Gridly](Documentation/ImportGridly.png)

### Downloading Source Changes
The **Download Source Changes** feature allows you to pull source string modifications from Gridly into Unreal Engine 5. This feature downloads source strings from Gridly per namespace, generates CSV files for each string table, and **automatically imports them into UE5's localization manifests**.
 **Important**: This feature modifies source strings in your localization files. Review all changes before committing to version control.
### Creating New String Tables from Gridly
The **Download Source Changes** feature also supports creating new string tables directly from Gridly data. To create a new string table:
1. **Set path for the new string tables**: You have to set a path in the plugin settings where the new string tables will be saved.
2. **Enable Combined Namespace ID**: This feature only works when the "Use Combined Namespace Id" setting is enabled in the plugin settings.
3. **Create a Path in Gridly**: Create a new path in your Grid. The path name will become the string table name in UE5.
4. **Set Record ID Format**: Use the format `"StringTableName,Key"` for your record IDs, where:
   - `StringTableName` is the desired name of your string table (must match the path name)
   - `Key` is the unique identifier for the text entry
   - Example: `"B_table,button_text"` or `"MainMenu,start_button"`
5. **Organize Records**: Place all records that should belong to the same string table under the same path in Gridly.
6. **Download Changes**: Use the "Download Source Changes" feature to automatically create the string table and import the entries.
7. **Gather Text**: Use the Gather Text feature in the localization dashboard to gather content in the localization dashboard.
**Example Setup**:
- Gridly Path: `B_table`
- Record IDs: `"B_table,button_text"`, `"B_table,title_text"`, `"B_table,description"`
- Result: Creates a string table named `B_table` with the specified entries
 **Note**: The string table name in UE5 will match exactly with your Gridly path name (no "StringTable_" prefix is added).

### Exporting Translations

If you have existing translations in UE5.6, these can also be exported to Gridly with a single click (you usually only need to do this once).

![Export all to Gridly](Documentation/ExportTranslations.png)

## Live Preview

The Gridly plugin also supports updating translations during runtime using the provided Blueprint functions to enable preview mode:

![Enable Live Preview Blueprint](Documentation/EnableLivePreviewBlueprint.png)

After making changes on Gridly, the translations can then be updated using the following:

![Update Live Preview Blueprint](Documentation/UpdateLivePreviewBlueprint.png)

While possible, it is currently *not* recommended to use this mode in a production build! This functionality is for development only (either in PIE mode or Development build). When final translations are ready, you should import your translations [through the Localization Dashboard](#markdown-header-importing-translations).

## Gridly Data Table

The Gridly Data Table is a data table that can be used like a regular data table in UE5.6 as part of your game's logic. The extra functionality that this plugin provides is that the data can also be edited through the Gridly web app, and synchronized with UE5.6 both during development and even in the packaged project. To get started, right click in the asset browser to create a Gridly Data Table:

![Create Gridly Data Table](Documentation/CreateGridlyDataTable.png)

You need to select a Structure data type for each row (or a `USTRUCT` that inherits `FTableRowBase` if you're using C++). The difference between GridlyDataTable and a regular data table is that it is mapped to a particular view on Gridly. You can set the view ID that the table is mapped to in the *Data Table Details* panel:

![Set Gridly Data Table View ID](Documentation/SetGridlyDataTableViewId.png)

For the plugin to map the data correctly between Gridly and UE5.6, the variable names of the Structure needs to be named the exact same as the column IDs of the view you are synchronizing with. Create an empty grid on Gridly and create columns with column IDs that match your Structure variables.

![Create Gridly Data Grid](Documentation/CreateGridlyDataGrid.png)

![Configure Gridly Data Columns](Documentation/ConfigureGridlyDataColumns.png)

Currently, the Gridly Data Table supports synchronizing *Boolean*, *Integer*, *Float*, *String* and *Enum* types. 

You can now import/export data from UE5.6 to Gridly:

![Import/export Gridly Data Table](Documentation/ImportExportGridlyDataTable.png)

## Configuring Gridly

All the settings for Gridly can be found in `Edit -> Project Settings -> Plugins -> Gridly`. They can also be found in `Config/DefaultGame.ini` if you prefer to edit these options by hand.

### Import/export Settings

![API keys and view IDs](Documentation/GridlyAPISettings.png)

- *Import Api Key*: This is the API key used for importing translations from Gridly.
- *Import from View Ids*: This is a list of view IDs on Gridly to import from. We will fetch from all view IDs and combine the results. Only one record will be used in case of duplicate record IDs. This will be used for both regular import as well as in Live Preview mode.

- *Export Api Key*: This is the API key used for exporting source strings. Make sure it has write-permissions.
- *Export View Id*: This is the view ID on Gridly that source strings should be exported to.

### Per-Target Gridly Connections

If your project has more than one localization target and each target should sync with a different Gridly view (or even a different Gridly account), you can map each target to its own connection instead of sharing one set of global keys.

The settings live in the **`Gridly | Connection Mode`** category in `Edit -> Project Settings -> Plugins -> Gridly`:

- *Use Per Target Connections*: A switch that controls which connection the plugin reads.
  - **Off** (default): every target uses the global *Import Api Key* / *Import from View Ids* / *Export Api Key* / *Export View Id* fields described above. This is the original behaviour — existing projects need no changes.
  - **On**: each localization target reads its own entry from *Target Connections* (described below). Targets that have no entry fall back to the global fields, so you can opt-in target by target.
- *Target Connections*: A map keyed by the localization target name (the same name shown in the Localization Dashboard). Each entry contains its own *Import Api Key*, *Import from View Ids*, *Import Max Records Per Request*, *Export Api Key*, *Export View Id*, and *Export Max Records Per Request*.
- *Available Target Names*: A read-only list of localization target names discovered in your project. Use these as the keys when adding entries to *Target Connections*.
- *Refresh Localization Target Names*: A button that re-scans the project's localization targets (both the game target set and the engine target set) and refreshes *Available Target Names*. Press this after you create, rename, or remove a localization target so the dropdown reflects the current state.

Keys are matched case-sensitively against `ULocalizationTarget::Settings.Name`, so use the names from *Available Target Names* verbatim. The same per-target connection is used for *Export to Gridly*, *Export All*, *Import from Gridly*, and *Download Source Changes* on that target.

When per-target mode is enabled, the global Import/Export fields are disabled in the UI but still readable; they continue to act as the fallback for any target that does not have an explicit entry and for runtime Blueprint nodes like *Download Localized Texts*.

### Column Mapping Options

![Column Mapping Options](Documentation/ColumnMappingOptions.png)

- *Use Combined Namespace Id*: If you have specified a namespace for your source strings, it will be combined with the key before being sent to Gridly, in the form of `Namespace,Key`. Likewise, it will expect the record ID fetched from Gridly to be in this form and convert it during import. Do not change once configured!

- *Also Export Namespace Column*: If you are using the above option, you can optionally also export the namespace to a separate column in addition to being used in the ID for translation reference/path tag organization.

- *Namespace Column Id*: The column ID on Gridly to map the namespace in Unreal to. By default, this is `path`, which is the path tag column. This can be set to any column ID that is configured to be a string. This option works for both import and export. Do not change once configured!

- *Source Language Column Id Prefix*: All source language columns on Gridly are expected to use culture mapping as configured below and prefixed with this value. Make sure this matches the column IDs on Gridly.

- *Target Language Column Id Prefix*: All target language columns on Gridly are expected to use culture mapping as configured below and prefixed with this value. Make sure this matches the column IDs on Gridly.

### Custom Culture Mapping

By default, the Gridly plugin will automatically convert language/culture codes of the format `en-US` in Unreal to what Gridly uses, which is generally `enUS` (without the hyphen). You can also completely customize this behaviour by using custom culture mapping.

![Custom Culture Mapping](Documentation/CustomCultureMapping.png)

