// Copyright (c) 2021 LocalizeDirect AB

#pragma once

#include "CoreMinimal.h"

#include "ILocalizationServiceOperation.h"
#include "ILocalizationServiceProvider.h"
#include "ILocalizationServiceState.h"
#include "Interfaces/IHttpRequest.h"
#include <string>
#include <fstream>
#include <iostream>


class FGridlyLocalizationServiceProvider final : public ILocalizationServiceProvider
{


	class FGridlyTypeRecord
	{
	public:
		FString Id;
		FString Path;

		FGridlyTypeRecord(const FString& InId, const FString& InPath)
			: Id(InId), Path(InPath)
		{}
	};

	class FGridlySourceRecord
	{
	public:
		FString RecordId;
		FString Path;
		FString SourceText;

		FGridlySourceRecord()
			: RecordId(TEXT("")), Path(TEXT("")), SourceText(TEXT(""))
		{}
	};
public:
	FGridlyLocalizationServiceProvider();
	bool bHasDeletesPending = false;
	
	// Manifest handling functions
	bool ImportKeyValuePairsToStringTable(ULocalizationTarget* LocalizationTarget, const FString& Namespace, const TMap<FString, FString>& KeyValuePairs);
	bool HasDeleteRequestsPending() const;

public:
	/* ILocalizationServiceProvider implementation */

	virtual void Init(bool bForceConnection = true) override;
	virtual void Close() override;
	virtual FText GetStatusText() const override;
	virtual bool IsEnabled() const override;
	virtual bool IsAvailable() const override;
	virtual const FName& GetName(void) const override;
	virtual const FText GetDisplayName() const override;
	virtual ELocalizationServiceOperationCommandResult::Type GetState(
		const TArray<FLocalizationServiceTranslationIdentifier>& InTranslationIds,
		TArray<TSharedRef<ILocalizationServiceState, ESPMode::ThreadSafe>>& OutState,
		ELocalizationServiceCacheUsage::Type InStateCacheUsage) override;
	virtual ELocalizationServiceOperationCommandResult::Type Execute(
		const TSharedRef<ILocalizationServiceOperation, ESPMode::ThreadSafe>& InOperation,
		const TArray<FLocalizationServiceTranslationIdentifier>& InTranslationIds,
		ELocalizationServiceOperationConcurrency::Type InConcurrency = ELocalizationServiceOperationConcurrency::Synchronous,
		const FLocalizationServiceOperationComplete& InOperationCompleteDelegate =
		FLocalizationServiceOperationComplete()) override;
	virtual bool CanCancelOperation(
		const TSharedRef<ILocalizationServiceOperation, ESPMode::ThreadSafe>& InOperation) const override;
	virtual void CancelOperation(const TSharedRef<ILocalizationServiceOperation, ESPMode::ThreadSafe>& InOperation) override;
	virtual void Tick() override;

#if LOCALIZATION_SERVICES_WITH_SLATE
	virtual void CustomizeSettingsDetails(IDetailCategoryBuilder& DetailCategoryBuilder) const override;
	virtual void CustomizeTargetDetails(
		IDetailCategoryBuilder& DetailCategoryBuilder, TWeakObjectPtr<ULocalizationTarget> LocalizationTarget) const override;
	virtual void CustomizeTargetToolbar(
		TSharedRef<FExtender>& MenuExtender, TWeakObjectPtr<ULocalizationTarget> LocalizationTarget) const override;
	virtual void CustomizeTargetSetToolbar(
		TSharedRef<FExtender>& MenuExtender, TWeakObjectPtr<ULocalizationTargetSet> LocalizationTargetSet) const override;
	void AddTargetToolbarButtons(FToolBarBuilder& ToolbarBuilder, TWeakObjectPtr<ULocalizationTarget> LocalizationTarget,
		TSharedRef<FUICommandList> CommandList);
#endif	  // LOCALIZATION_SERVICES_WITH_SLATE

	// functions to run export/import from commandlet
	FHttpRequestCompleteDelegate CreateExportNativeCultureDelegate();
	bool HasRequestsPending() const;

	void ExportForTargetToGridly(ULocalizationTarget* LocalizationTarget, FHttpRequestCompleteDelegate& ReqDelegate, const FText& SlowTaskText, bool bIncTargetTranslation = false);

	/** Name of the localization target driving the in-flight export. Used by FetchGridlyCSV/DeleteRecordsFromGridly to resolve the right connection. */
	FString LastExportTargetName;

	// New functions for fetching and parsing CSV from Gridly
	void FetchGridlyCSV(); // Fetches the CSV data from Gridly
	void OnGridlyCSVResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful); // Callback for when the CSV is received
	void ParseCSVAndCreateRecords(const FString& CSVContent); // Parses CSV content and creates records

private:
	// Import
	bool IsFileNotEmpty(const std::string& filePath);
	void ImportAllCulturesForTargetFromGridly(TWeakObjectPtr<ULocalizationTarget> LocalizationTarget, bool bIsTargetSet);
	void OnImportCultureForTargetFromGridly(const FLocalizationServiceOperationRef& Operation,
		ELocalizationServiceOperationCommandResult::Type Result, bool bIsTargetSet);
	TSharedPtr<FScopedSlowTask> ImportAllCulturesForTargetFromGridlySlowTask;
	TArray<FString> CurrentCultureDownloads;
	int SuccessfulDownloads;
	size_t ExportForTargetEntriesDeleted = 0;


	// Export

	size_t ExportForTargetEntriesUpdated;
	TSharedPtr<FScopedSlowTask> ExportForTargetToGridlySlowTask;
	TQueue<TSharedPtr<IHttpRequest, ESPMode::ThreadSafe>> ExportFromTargetRequestQueue;
	bool bExportRequestInProgress = false;

	void ExportNativeCultureForTargetToGridly(TWeakObjectPtr<ULocalizationTarget> LocalizationTarget, bool bIsTargetSet);
	void OnExportNativeCultureForTargetToGridly(FHttpRequestPtr HttpRequestPtr, FHttpResponsePtr HttpResponsePtr, bool bSuccess);

	// Export all

	void ExportTranslationsForTargetToGridly(TWeakObjectPtr<ULocalizationTarget> LocalizationTarget, bool bIsTargetSet);
	void OnExportTranslationsForTargetToGridly(FHttpRequestPtr HttpRequestPtr, FHttpResponsePtr HttpResponsePtr, bool bSuccess);

	// Download source changes
public:
	void DownloadSourceChangesFromGridly(TWeakObjectPtr<ULocalizationTarget> LocalizationTarget, bool bIsTargetSet);
	void OnDownloadSourceChangesFromGridly(FHttpRequestPtr HttpRequestPtr, FHttpResponsePtr HttpResponsePtr, bool bSuccess);

	TArray<FGridlyTypeRecord> GridlyRecords; // List to store the records from Gridly
	TArray<FGridlyTypeRecord> UERecords;
	FString RemoveNamespaceFromKey(FString& InputString);
	
	void DeleteRecordsFromGridly(const TArray<FString>& RecordsToDelete);
	void OnDeleteRecordsResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);

	// Source changes download tracking
	TWeakObjectPtr<ULocalizationTarget> CurrentSourceDownloadTarget;
	FString CurrentSourceDownloadCulture;
	// Pagination state for the source-changes download. Gridly's /views/{id}/records endpoint
	// is paginated; we accumulate every page's records before processing.
	TMap<FString, TArray<FGridlySourceRecord>> AccumulatedSourceNamespaceRecords;
	int32 CurrentSourceDownloadOffset = 0;
	int32 SourceDownloadLimit = 0;
	int32 SourceDownloadTotalCount = 0;
	// True while a source-changes download (pagination + post-processing) is in flight.
	// The commandlet path polls this so it can wait for the async provider flow to complete.
	bool bSourceChangesDownloadInProgress = false;
public:
	bool IsSourceChangesDownloadInProgress() const { return bSourceChangesDownloadInProgress; }
	void DownloadSourceChangesFromGridlyInternal(TWeakObjectPtr<ULocalizationTarget> LocalizationTarget, const FString& NativeCulture);
	void RequestSourceChangesPage(int32 Offset);
	void ProcessSourceChangesForNamespaces(const TMap<FString, TArray<FGridlySourceRecord>>& NamespaceRecords);
	bool ImportCSVToStringTable(ULocalizationTarget* LocalizationTarget, const FString& Namespace, const FString& CSVFilePath);
	void ParseCSVLine(const FString& Line, TArray<FString>& OutFields);
	void ParseCSVRecords(const FString& Content, TArray<TArray<FString>>& OutRecords);
	

	
	// String table helper functions
	UStringTable* FindOrCreateStringTable(const FString& Namespace);
	


	int32 CompletedBatches;         // Track the number of completed batches
	int32 TotalBatchesToProcess;    // Track the total number of batches
};
